# Mairie360 frontend kit

Shared code for the eight active frontends. The UI library is independent of this package.

- `./guard`: document presence/expiry guard and CSP; data routes return JSON 401, documents resume through their own `/api/auth/resume`.
- `./next`: bounded published-contract BFF proxy, Login-owned refresh/revocation, peer refresh/resume handlers and HttpOnly cookie helpers.
- `./browser`: a single-flight same-origin refresh and one replay after 401. A refused refresh returns the original authentication failure; outages remain retryable.
- `./shared`: validated public URLs, CSP, display-only JWT role aliases and instance civil-date helpers.
- `./react`: server-initialized display role and instance timezone providers.

Set `INSTANCE_TIMEZONE` to one IANA timezone for the instance, for example `Indian/Reunion`. An absent or invalid value uses UTC consistently. This public configuration is read at runtime and sent by the root layout. BFF/API conversion is a separate dependency; frontend formatting does not rewrite server timestamps or interpret timezone-less event clocks as UTC.

Login remains the owner of `/auth/refresh` and `/auth/logout`. Each peer exposes `/api/auth/refresh` (POST, same-origin JSON) and `/api/auth/resume` (GET, validated local document path). The refresh cookie remains HttpOnly, Secure in production, SameSite Strict, path `/api`; its browser lifetime is 30 days. Actual server session retention must agree before a 30-day service lifetime can be claimed. No bearer or refresh token enters JavaScript, a URL, storage or a log.

The JWT role is decoded only to display navigation immediately. Missing, expired, malformed or unknown claims display Guest. BFF/API checks remain authoritative for all operations.

Run `npm ci --ignore-scripts`, `npm test`, `npm audit --audit-level=high`. The package has its own lock and audit; it does not inherit or waive the UI library's audit findings. Frontends can consume the exact packed artifact during review; its checksum and source commit must be recorded. A registry release is a separate verifiable publication.

## Français

Le paquet partage les sessions, le proxy, la garde, la CSP, les URL et le fuseau des huit fronts. Les données répondent 401 en JSON ; les pages passent par une reprise locale et ne montrent Login que si la session est refusée. Les requêtes simultanées partagent leur renouvellement. La révocation est effectuée par Login après action explicite. Le rôle du JWT sert uniquement à afficher la navigation ; il ne donne aucun droit.

`INSTANCE_TIMEZONE` configure le fuseau IANA public de l’instance. Le repli unique est UTC. Les changements correspondants dans les BFF/API et la rétention serveur de 30 jours restent des dépendances distinctes, sans modification ici. Les dates civiles sont conservées, les instants sont affichés dans le fuseau de l’instance. Les audits, seuils et protections ne sont pas abaissés.
